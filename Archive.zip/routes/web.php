<?php

use App\Http\Controllers\BlogController;
use App\Http\Controllers\AboutController;
use Illuminate\Support\Facades\Route;
use App\Models\Blog;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/about',[BlogController::class, 'index']);


Route::get('/blogs/{blog:slug}',[AboutController::class, 'show']);

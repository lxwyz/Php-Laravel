<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <ul>
        <li>
            <a href="/">Home</a>
            <a href="/about">About</a>

            <h1>My Blogs</h1>

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2>
                <a href="/blogs/<?php echo e($blog->slug); ?>">
                    <?php echo e($blog->title); ?>;
                </a>
            </h2>
            <p><?php echo e($blog->body); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p>category</p>


        </li>
    </ul>
</body>
</html>
<?php /**PATH /Users/thantsinlin/blog-application/resources/views/about.blade.php ENDPATH**/ ?>
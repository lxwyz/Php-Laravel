<?php

namespace App\Http\Controllers;
use App\Models\Blog;

use Illuminate\Http\Request;

class AboutController extends Controller
{

    public function show(Blog $blog) {
        // if(!is_numeric($id))
        // {
        //     return abort(404);
        // }
        // $blog = Blog::find($id);
        return view('blogs-detail',[
            "blog" => $blog
        ]);

        // $blog = Blog::findOrFail($id);
        // return $blogs;
    }
}

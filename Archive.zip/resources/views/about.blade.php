<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <ul>
        <li>
            <a href="/">Home</a>
            <a href="/about">About</a>

            <h1>My Blogs</h1>

            @foreach ($blogs as $blog)
            <h2>
                <a href="/blogs/{{$blog->slug}}">
                    {{$blog->title}};
                </a>
            </h2>
            <p>{{$blog->body}}</p>
            @endforeach
            <p>category</p>


        </li>
    </ul>
</body>
</html>
